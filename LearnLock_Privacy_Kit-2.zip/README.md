
# LearnLock Privacy Policy

This repository contains the privacy policy for the **LearnLock** Android app — an educational lock screen for children.

## View Policy

You can view the live privacy policy here:  
**https://kenj84.github.io/learnlock-privacy/LearnLock_Privacy_Policy.html**

## About LearnLock

LearnLock replaces the standard lock screen with fun, curriculum-aligned questions for children. Features include:
- Random educational questions on unlock
- Parent-controlled subjects and difficulty
- Emergency PIN access
- Local-only data storage

## Permissions Required

- **Accessibility Services:** To keep LearnLock secure and persistent
- **Overlay Permission:** To draw questions over the default lock screen
- **Boot Permission:** To restore functionality after reboot

## Contact

For support or questions, please email: `kennyjermyn84@hotmail.com`
